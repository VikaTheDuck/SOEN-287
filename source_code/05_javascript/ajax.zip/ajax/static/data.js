function loadData() {
    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            let div = document.getElementById("dataDiv");
            div.innerText = xhttp.responseText;
        }
    };
    xhttp.open("GET", "/data", true);
    xhttp.send();
}

function loadData2() {
    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            let obj = JSON.parse(xhttp.responseText);
            let list = document.getElementById("dataList");
            for (key in obj) {
                let dt = document.createElement("dt");
                dt.innerText = key;
                list.appendChild(dt);
                let dd = document.createElement("dd");
                dd.innerText = obj[key];
                list.appendChild(dd);
            }
        }
    };
    xhttp.open("GET", "/data", true);
    xhttp.send();
}
